import { View, Text } from 'react-native'
import React from 'react'

export default function Favourites() {
  return (
    <View>
      <Text>Favourites</Text>
    </View>
  )
}